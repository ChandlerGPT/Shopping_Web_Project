<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>Insert customer</title>  
	</head> 
	
	<body> 
		<?php
			$server = "localhost";$user = "wbip";$pw = "wbip123";$db = "test";
			$connect=mysqli_connect($server, $user, $pw, $db);
			
			$userid=$_POST['userid'];
			$password=$_POST['password'];
			$nickname=$_POST['nickname'];
			$email=$_POST['email'];
			$gender=$_POST['gender'];
			$birthday=$_POST['birthday'];
			$type="customer";
			$fileName = basename($_FILES['profile']['name']); 
			
				$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
				$allowTypes = array('jpg','png','jpeg','gif');
				if(in_array($fileType, $allowTypes)){ 
					$image = $_FILES['profile']['tmp_name']; 
					$imgContent = addslashes(file_get_contents($image));	
				}
				$userQuery = "INSERT INTO users(userid,nickname,email,profile,gender,birthday,type,password) VALUE ('".$userid."','".$nickname."','".$email."','".$imgContent."','".$gender."','".$birthday."','".$type."','".$password."')";
				mysqli_query($connect, $userQuery);
				$_SESSION["type"] = $type;
				$_SESSION["userid"] = $userid;
				header("location:userhome.php");
			
			mysqli_close($connect);
			?>
	</body>
</html> 
 