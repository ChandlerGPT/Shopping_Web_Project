<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	$itemid = $_POST["itemid"];
	$userQuery="SELECT * FROM item WHERE itemid='$itemid'";
	$result=mysqli_query($connect, $userQuery);
	$rr=mysqli_fetch_assoc($result);
	$price=$rr['price'];
	$quantity=0;
	$userQuery="SELECT * FROM cart WHERE itemid='$itemid' and userid='$userid'";
	$result=mysqli_query($connect, $userQuery);
	if($rr=mysqli_fetch_assoc($result)){
		$quantity=$rr['quantity'];
	}
	
	$quantity=$quantity+1;
	$userQuery="DELETE FROM cart WHERE itemid='$itemid' and userid='$userid'";
	$result=mysqli_query($connect, $userQuery);
	
	$userQuery = "INSERT INTO cart(userid,itemid,quantity,price) VALUE ('".$userid."','".$itemid."','".$quantity."','".$price."')";
	mysqli_query($connect, $userQuery);
	
	
	//$_SESSION["userid"] = $userid;
	header("location:cart.php");
	
	mysqli_close($connect);
?>