<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>Personal Records</title>  
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head> 
	
	
	<body> 
			<?php	
				$userid="admin";
				$type="admin";
				$_SESSION["type"] = $type;
				$_SESSION["userid"] = $userid;
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a  class=\"active\" href=\"check.php\">Check</a></li>
					<li><a  href=\"add.html\">Add</a></li>
					<li style=\"float:right\"><a href=\"adminpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				print("<br><br>");
				$id=$_POST['userid'];
				print("<table>");
				$userQuery = "SELECT * FROM buyerinfo INNER JOIN users ON users.userid=buyerinfo.userid WHERE buyerinfo.userid='$id' ORDER BY nickname";
				$result=mysqli_query($connect, $userQuery);
				$sum=0;
				while($rr=mysqli_fetch_assoc($result)){
					$buyerid=$rr['userid'];
					$itemid=$rr['itemid'];
					$nickname=$rr['nickname'];
					$userQuery1 = "SELECT * FROM item where itemid='$itemid'";
					$result1=mysqli_query($connect, $userQuery1);
					$r=mysqli_fetch_assoc($result1);
					$imgdata=base64_encode($r['picture']);
					$quantity=$rr['quantity'];
					$price=$rr['price'];
					print("<tr><th>UserID:$buyerid NickName:$nickname</th><td><img class=\"item\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></td>
						<td><p>Quantity:".strval($rr['quantity'])."</p><p>Total Price:$".strval($rr['price'])."</p></td>
						</tr>");
					
				}
				print("</table>");
				mysqli_close($connect);
			?>

	</body>
</html> 
 