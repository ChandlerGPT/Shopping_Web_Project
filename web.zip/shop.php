<?php
	if(isset($_COOKIE["userid"])&&isset($_COOKIE["type"])) {
		header("location:userhome.php");
	}
?>
<!DOCTYPE html>
<html>

	<head>
		<title>The Chandler Shop</title>
		<script src="login.js"></script>
		<link rel="stylesheet" type="text/css" href="oj.css"/>
	</head>
	
	<body style="background-image:url('background.jfif');background-repeat:no-repeat;background-size:cover;background-attachment:fixed">
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
		<form action = "userhome.php" method = "post" id = "userhome">
			<table class="button4">
			<tr>
				<td><b>Userid:</b></td> <td><input  type="text" id="userid" name="userid"></td>
			</tr>
			<tr>
				<td><b>Password :</b></td> <td><input  type="text" id="password"></td>
			</tr>
			<tr>
				<td>
				<select class="button4" id = "type" name="type">
				<option value = "customer">Customer</option>
				<option value = "admin">Admin</option>
				</select>
				</td>
			</tr>
			</table>
			<p align="center"><input class="button1" type="button" value="login" onclick="verify();"> Not a member? <a href="sign-up.html"><font  color="blue">Click here to sign up!</a></p>
			<p align="center"><a href="forget.php"><font  color="blue">Forget PassWord?</a></p>
		</form>
		<br>
		<div id="status" align="center"></div>
		<p id="tst"></p>
		<?php
		
		?>

	</body>
	
</html>