<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	
	$userQuery="SELECT * FROM cart WHERE userid='$userid'";
	$result=mysqli_query($connect, $userQuery);
	$flag=true;
	while($rr=mysqli_fetch_assoc($result)){
		$itemid = $rr["itemid"];
		$quantity = $rr["quantity"];
		$userQuery="SELECT * FROM item WHERE itemid='$itemid'";
		$result1=mysqli_query($connect, $userQuery);
		$r=mysqli_fetch_assoc($result1);
		$stock=$r["quantity"];
		//print($stock."-".$quantity."=".$stock-$quantity);
		if($stock-$quantity<=-1){
			$flag=false;
		}
	}
	
	if($flag==false){
		print "Item Stock Is Not Enough";
	}
	else{
		$userQuery="SELECT * FROM cart WHERE userid='$userid'";
		$result=mysqli_query($connect, $userQuery);
		while($rr=mysqli_fetch_assoc($result)){
			$itemid = $rr["itemid"];
			$quantity = $rr["quantity"];
			$price=$rr['price'];
			$userQuery="SELECT * FROM item WHERE itemid='$itemid'";
			$result1=mysqli_query($connect, $userQuery);
			$r=mysqli_fetch_assoc($result1);
			$stock=$r["quantity"];
			$stock=$stock-$quantity;
			$total=$price*$quantity;
			$userQuery = "UPDATE item SET quantity='$stock' WHERE itemid=$itemid";
			mysqli_query($connect, $userQuery);
			$userQuery = "INSERT INTO buyerinfo(userid,itemid,quantity,price) VALUE ('".$userid."','".$itemid."','".$quantity."','".$total."')";
			mysqli_query($connect, $userQuery);
		}
		$userQuery="DELETE FROM cart WHERE userid='$userid'";
		$result=mysqli_query($connect, $userQuery);
		print "Successful";
	}
	
	mysqli_close($connect);
?>