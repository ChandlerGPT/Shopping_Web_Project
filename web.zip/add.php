<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$itemid = $_POST['itemid'];
	$userQuery="SELECT * from item";
	$result=mysqli_query($connect, $userQuery);
	$price=$_POST['price'];
	$quantity=$_POST['quantity'];
	$type=$_POST['type'];
	$fileName = basename($_FILES['profile']['name']); 
	$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
	$allowTypes = array('jpg','png','jpeg','gif');
	if(in_array($fileType, $allowTypes)){ 
		$image = $_FILES['profile']['tmp_name']; 
		$imgContent = addslashes(file_get_contents($image));	
	}

	$userQuery = "INSERT INTO item(itemid,price,quantity,type,picture) VALUE ('".$itemid."','".$price."','".$quantity."','".$type."','".$imgContent."')";
	mysqli_query($connect, $userQuery);
	
	header("location:adminpage.php");
	
	mysqli_close($connect);
?>