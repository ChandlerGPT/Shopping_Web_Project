<?php
	setcookie("userid", "",  time()-(60 * 60 * 24));
	setcookie("type", "",  time()-(60 * 60 * 24));
	session_start();
	session_unset();
	session_destroy();
	header("location:shop.php");
?>