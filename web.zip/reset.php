<?php
	$userid = $_GET['userid'];
	$password = $_GET['password'];
	$type = $_GET['type'];
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userQuery = "SELECT userid,type FROM users
	WHERE userid = '$userid' and type='$type'";
	$result = mysqli_query($connect, $userQuery);
	if (!$result) {
		die("Could not successfully run query.");
	}
	
	if (mysqli_num_rows($result) == 0) {
		print "<p>No Userid matched</p>";
	}else {
		$userQuery = "UPDATE users set password='$password'
		WHERE userid = '$userid' and type='$type'";
		$result = mysqli_query($connect, $userQuery);
		setcookie("userid","$userid", time() + (60 * 60 * 24));
		setcookie("type","$type", time() + (60 * 60 * 24));
		print "Successful";
	}
	
	mysqli_close($connect);
?>