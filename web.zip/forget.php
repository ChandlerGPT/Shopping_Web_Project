<!DOCTYPE html>
<html>

	<head>
		<title>Reset Password</title>
		<script src="forget.js"></script>
		<link rel="stylesheet" type="text/css" href="oj.css"/>
	</head>
	
	<body style="background-image:url('background.jfif');background-repeat:no-repeat;background-size:cover;background-attachment:fixed">
		<br><br><br><br><br><br><br><br><br><br><br><br><br>
		<form action = "userhome.php" method = "post" id = "forget">
			<table class="button4">
			<tr>
				<td><b>Your Userid:</b></td> <td><input  type="text" id="userid" name="userid"></td>
			</tr>
			<tr>
				<td><b>New Password :</b></td> <td><input  type="text" id="password"></td>
			</tr>
			</table>
			<p align="center"><input class="button1" type="button" value="Reset" onclick="verify();"></p>
			
		</form>
		<br>
		<div id="status" align="center"></div>
		<p id="tst"></p>
		<?php
		
		?>

	</body>
	
</html>