<?php
	session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>User Page</title>
	<link rel="stylesheet" type="text/css" href="oj.css"/>
</head>
	
<body style="background-image:url('background.jfif');background-repeat:no-repeat;background-size:cover;background-attachment:fixed">
	<?php	
		
		$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
		$connect = mysqli_connect($server, $user, $pw, $db);
		$type=$_SESSION["type"];
		$userid=$_SESSION["userid"];
		$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
		$result=mysqli_query($connect, $userQuery);
		while($rr=mysqli_fetch_assoc($result)){
			$imgdata=base64_encode($rr['profile']);
			$nickname=$rr['nickname'];
		}
		if($imgdata==""){
			$userQuery = "SELECT * FROM users where userid='unknown' and type='customer'";
			$result=mysqli_query($connect, $userQuery);
			while($rr=mysqli_fetch_assoc($result)){
				$imgdata=base64_encode($rr['profile']);
			}
		}
		print("
		<table>
			<tr>
				<td><img src=\"data:image/jpg;charset=utf8;base64,$imgdata\" >
				<p>Hi $nickname!</p></td>
			</tr>
			<tr>
				<td>
					<ul>
					<li><a href=\"userhome.php\">Home Page</a></li>
					<li><a href=\"cart.php\">My Cart</a></li>
					<li><a href=\"history.php\">Purchase History</a></li>
					<li><a href=\"modify.html\">Modify Information</a></li>
					<li><a href=\"logout.php\">Log Out</a></li>
					
					</ul>
				</td>
			</tr>
		</table>
		
		");
		
		mysqli_close($connect);
	?>
</body>
</html>