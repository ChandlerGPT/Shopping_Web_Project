<?php
	$userid = $_GET['userid'];
	$password = $_GET['password'];
	$type = $_GET['type'];
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userQuery = "SELECT userid, password,type FROM users
	WHERE userid = '$userid' and password = '$password' and type='$type'" ;
	$result = mysqli_query($connect, $userQuery);
	if (!$result) {
		die("Could not successfully run query.");
	}
	
	if (mysqli_num_rows($result) == 0) {
		print "<p>Wrong UserId or Password!!</p>";
	}else {
		print "Login successfully!!!";
	}
	
	mysqli_close($connect);
?>