<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	$itemid = $_POST["itemid"];
	$price = $_POST["price"];
	$userQuery="UPDATE item SET price='$price' WHERE itemid='$itemid'";
	mysqli_query($connect, $userQuery);
	//$_SESSION["userid"] = $userid;
	header("location:check.php");
	
	mysqli_close($connect);
?>