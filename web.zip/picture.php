<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	$itemid = $_POST["itemid"];
	$userQuery="SELECT * from item WHERE itemid='$itemid'";
	$result=mysqli_query($connect, $userQuery);
	while($rr=mysqli_fetch_assoc($result)){
		$price=$rr['price'];
		$quantity=$rr['quantity'];
		$type=$rr['type'];
	}
	$fileName = basename($_FILES['picture']['name']); 
	
	$fileType = pathinfo($fileName, PATHINFO_EXTENSION);
	$allowTypes = array('jpg','png','jpeg','gif');
	if(in_array($fileType, $allowTypes)){ 
		$image = $_FILES['picture']['tmp_name']; 
		$imgContent = addslashes(file_get_contents($image));	
	}
	$userQuery="UPDATE item SET picture='$imgContent' where itemid='$itemid'";
	mysqli_query($connect, $userQuery);
	/*$userQuery = "DELETE from item where itemid=$itemid";
	mysqli_query($connect, $userQuery);
	$userQuery = "INSERT INTO item(itemid,price,quantity,type,picture) VALUE ('".$itemid."','".$price."','".$quantity."','".$type."','".$imgContent."')";
	mysqli_query($connect, $userQuery);*/
	//$_SESSION["userid"] = $userid;
	header("location:check.php");
	
	mysqli_close($connect);
?>