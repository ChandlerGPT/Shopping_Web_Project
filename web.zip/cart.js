function verify() {
	
	var myRequest = new XMLHttpRequest();
	myRequest.open("GET", "buy.php?", true);
	myRequest.send();
	myRequest.onload = function(){
		alert(this.responseText);
		if(this.responseText=="Successful"){
			document.getElementById('buy').submit();
		}
	}
	
}