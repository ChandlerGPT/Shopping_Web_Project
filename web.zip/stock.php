<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	$itemid = $_POST["itemid"];
	$quantity = $_POST["quantity"];
	$userQuery="SELECT * FROM item";
	$result=mysqli_query($connect, $userQuery);
	$rr=mysqli_fetch_assoc($result);
	$price=$rr['price'];
	$userQuery="UPDATE item SET quantity='$quantity' WHERE itemid='$itemid'";
	mysqli_query($connect, $userQuery);
	header("location:check.php");
	
	mysqli_close($connect);
?>