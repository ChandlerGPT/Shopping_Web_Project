<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>My Cart</title>  
		<script src="cart.js"></script>
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head> 
	
	
	<body> 
			<?php	
				if (!isset($_POST['type'])&&!isset($_POST['userid'])){
					$type=$_SESSION["type"];
					$userid=$_SESSION["userid"];
				}
				else{
					$type = $_POST['type'];
					$_SESSION["type"] = $type;
					$userid = $_POST['userid'];
					$_SESSION["userid"] = $userid;
				}
				if($type=="admin"){
					header("location:adminpage.php");
				}
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				if($imgdata==""){
					$userQuery = "SELECT * FROM users where userid='unknown' and type='customer'";
					$result=mysqli_query($connect, $userQuery);
					while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
					}
				}
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a href=\"userhome.php\">All</a></li>
					<li><a href=\"Male.php\">Male</a></li>
					<li><a href=\"Female.php\">Female</a></li>
					<li><a  class=\"active\" href=\"cart.php\">Cart</a></li>
					<li style=\"float:right\"><a href=\"userpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				print("<br><br><p align=\"center\"><img src=\"shop.png\" width=\"400\"></p>");
				print("<table>");
				$sum=0;
				$userQuery = "SELECT * FROM cart where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$itemid=$rr['itemid'];
					$userQuery1 = "SELECT * FROM item where itemid='$itemid'";
					$result1=mysqli_query($connect, $userQuery1);
					$r=mysqli_fetch_assoc($result1);
					$imgdata=base64_encode($r['picture']);
					$Total=$rr['price']*$rr['quantity'];
					$sum=$sum+$Total;
					print("<tr><td><img class=\"item\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></td>
						<td><p>Price:$".strval($rr['price'])."</p><p>Quantity:".strval($rr['quantity'])."</p><p>Stock:".strval($r['quantity'])."</p></td>
						<td><p>
						<form action = \"quantity.php\" method = \"post\">
						<input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/>
						<input type=\"text\" id=\"quantity\" name=\"quantity\"/>
						<input class=\"button2\" type=\"submit\" value=\"Modify Quantity\"/>
						</form></p>
						</td>
						<td>Total Price:".strval($Total)."</td>
						</tr>");
					
				}
				print("</table>");
				print("<p align=\"center\">The Total Money is:$");
				print($sum);
				print("</p>");
				print("<form action=\"userhome.php\" method = \"post\" id=\"buy\"><p align=\"center\"><input class=\"button3\" type=\"button\" value=\"Buy All\" onclick=\"verify();\"/></p></form>");
				mysqli_close($connect);
			?>

	</body>
</html> 
 