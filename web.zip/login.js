function verify() {
	var userid = document.getElementById("userid").value;
	var password = document.getElementById("password").value;
	var flag=true;
	var al="";
	if(userid==""){
		al=al+"Please input UserId\n";
		flag=false;
	}
	if(password==""){
		al=al+"Please input Password";
		flag=false;
	}
	if(flag==false){
		alert(al);
	}
	if(flag==true){
		var type = document.getElementById("type").value;
		var myRequest = new XMLHttpRequest();
		myRequest.open("GET", "login.php?userid="+userid+
		"&password="+password+"&type="+type, true);
		myRequest.send();
		myRequest.onload = function(){
			document.getElementById("status").innerHTML =
			"<span style='color:red'>"+this.responseText+"</span>";
			if(this.responseText=="Login successfully!!!"){
				document.getElementById('userhome').submit();
			}
		}
	}
}