<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>Check</title>  
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head> 
	
	
	<body> 
			<?php	
				if (!isset($_POST['type'])&&!isset($_POST['userid'])){
					$type=$_SESSION["type"];
					$userid=$_SESSION["userid"];
				}
				else{
					$type = $_POST['type'];
					$_SESSION["type"] = $type;
					$userid = $_POST['userid'];
					$_SESSION["userid"] = $userid;
				}
				
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a  class=\"active\" href=\"check.php\">Check</a></li>
					<li><a  href=\"add.html\">Add</a></li>
					<li style=\"float:right\"><a href=\"adminpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				print("<br><br>");
				print("<table>");
				$userQuery = "SELECT * FROM item";
				$result=mysqli_query($connect, $userQuery);
				$sum=0;
				while($rr=mysqli_fetch_assoc($result)){
					$itemid=$rr['itemid'];
					$imgdata=base64_encode($rr['picture']);
					print("<tr><td><img class=\"item\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></td>
						<td><p>Price:$".strval($rr['price'])."</p><p>Stock:".strval($rr['quantity'])."</p><p>ID:".strval($rr['itemid'])."</p></td>
						<td><p>
						<form action = \"stock.php\" method = \"post\">
						<input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/>
						<input type=\"text\" id=\"quantity\" name=\"quantity\"/>
						<input class=\"button3\" type=\"submit\" value=\"Modify Stock\"/>
						</form></p>
						<p>
						<form action = \"price.php\" method = \"post\">
						<input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/>
						<input type=\"text\" id=\"price\" name=\"price\"/>
						<input class=\"button3\" type=\"submit\" value=\"Modify Price\"/>
						</form></p>
						<p>
						<form action = \"picture.php\" method = \"post\" enctype=\"multipart/form-data\">
						<input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/>
						<input class=\"button3\" type=\"file\"  id=\"picture\"  name=\"picture\" />
						<p><input class=\"button3\" type=\"submit\" value=\"Modify Picture\"/></p>
						</form></p>
						</td>
						<td><p>
						<form action = \"delete.php\" method = \"post\">
						<input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/>
						<input class=\"button3\" type=\"submit\" value=\"Delete Stock\"/>
						</form></p>
						</td>
						</tr>");
					
				}
				print("</table>");
				mysqli_close($connect);
			?>

	</body>
</html> 
 