<!DOCTYPE html>

<html>
<head>
	<title>Admin Page</title>
	<link rel="stylesheet" type="text/css" href="oj.css"/>
</head>
	
<body style="background-image:url('background.jfif');background-repeat:no-repeat;background-size:cover;background-attachment:fixed">
	<?php	
		
		$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
		$connect = mysqli_connect($server, $user, $pw, $db);
		$userid="admin";
		$userQuery = "SELECT * FROM users where userid='$userid' and type='admin'";
		$result=mysqli_query($connect, $userQuery);
		while($rr=mysqli_fetch_assoc($result)){
			$imgdata=base64_encode($rr['profile']);
		}
		print("
		
		<table>
			<tr>
				<td><img src=\"data:image/jpg;charset=utf8;base64,$imgdata\" >
				<p>Hi Admin!</p></td>
			</tr>
			<tr>
				<td>
					<ul>
					<li><a href=\"check.php\">Check Item</a></li>
					<li><a href=\"add.html\">Add Item</a></li>
					<li><a href=\"record.php\">Records</a></li>
					<li><a href=\"tst.php\">Chart</a></li>
					<li><a href=\"logout.php\">Log Out</a></li>
					</ul>
				</td>
			</tr>
		</table>
		
		");
		
		mysqli_close($connect);
	?>
</body>
</html>