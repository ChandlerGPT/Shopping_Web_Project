<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>History</title>  
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head> 
	
	
	<body> 
			<?php	
				if (!isset($_POST['type'])&&!isset($_POST['userid'])){
					$type=$_SESSION["type"];
					$userid=$_SESSION["userid"];
				}
				else{
					$type = $_POST['type'];
					$_SESSION["type"] = $type;
					$userid = $_POST['userid'];
					$_SESSION["userid"] = $userid;
				}
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				if($imgdata==""){
					$userQuery = "SELECT * FROM users where userid='unknown' and type='customer'";
					$result=mysqli_query($connect, $userQuery);
					while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
					}
				}
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a href=\"userhome.php\">All</a></li>
					<li><a href=\"Male.php\">Male</a></li>
					<li><a href=\"Female.php\">Female</a></li>
					<li><a href=\"cart.php\">Cart</a></li>
					<li style=\"float:right\"><a class=\"active\" href=\"userpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				print("<br><br>");
				print("<table>");
				$userQuery = "SELECT * FROM buyerinfo WHERE userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				$sum=0;
				while($rr=mysqli_fetch_assoc($result)){
					$itemid=$rr['itemid'];
					$userQuery1 = "SELECT * FROM item where itemid='$itemid'";
					$result1=mysqli_query($connect, $userQuery1);
					$r=mysqli_fetch_assoc($result1);
					$imgdata=base64_encode($r['picture']);
					$quantity=$rr['quantity'];
					$price=$rr['price'];
					print("<tr><td><img class=\"item\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></td>
						<td><p>Quantity:".strval($rr['quantity'])."</p><p>Total Price:$".strval($rr['price'])."</p></td>
						</tr>");
					
				}
				print("</table>");
				mysqli_close($connect);
			?>

	</body>
</html> 
 