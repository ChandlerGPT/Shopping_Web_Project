<?php
	session_start();
?>
<html>
	<head>  
		<title>Chart</title>  
		
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head>
	<body>
		<?php 
			$userid="admin";
				$type="admin";
				$_SESSION["type"] = $type;
				$_SESSION["userid"] = $userid;
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				$userQuery = "SELECT * FROM users where userid='$userid'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a  href=\"check.php\">Check</a></li>
					<li><a  href=\"add.html\">Add</a></li>
					<li style=\"float:right\"><a class=\"active\"  href=\"adminpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				$p=0;
				$userQuery = "SELECT itemid,SUM(quantity) AS cnt FROM buyerinfo GROUP BY itemid ORDER BY cnt DESC;";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$orderno[$p]=$rr['cnt'];
					$item[$p]="Item ".$rr['itemid'];
					$iname[$p]="Item ".$rr['itemid'];
					$p=$p+1;
				}
				$pp=0;
				while($pp<$p){
					$phpArray[$pp]=$orderno[$pp];
					$pp=$pp+1;
				}
				$pp=0;
				while($pp<$p){
					$phpArray1[$pp]=$item[$pp];
					$pp=$pp+1;
				}
				print("<br><br><br><br><br><br>");
				print("<p align=\"center\"><canvas  id=\"myCanvas\"></canvas></p>
				<p align=\"center\">Top 3 Best-selling Clothes are ");
				print(" ".$iname[0].",  ".$iname[1].", ".$iname[2]."</p> <p align=\"center\">There Order Numbers are ".$phpArray[0]." , ".$phpArray[1]." , ".$phpArray[2]."</p>");
				
		?>
		
		
	</body>

<script type="text/javascript">
     (function (){
 
         window.addEventListener("load", function(){
			var data= <?php echo json_encode($phpArray ); ?>;
			var xinforma= <?php echo json_encode($phpArray1 ); ?>;

           
		   var myCanvas = document.getElementById("myCanvas");
			myCanvas.width = 1300;
			myCanvas.height = 1300;
		   
		   var ctx = myCanvas.getContext("2d");
          
			
		   function drawLine(ctx, startX, startY, endX, endY){
				ctx.beginPath();
				ctx.moveTo(startX,startY);
				ctx.lineTo(endX,endY);
				ctx.stroke();
			}
			function drawArc(ctx, centerX, centerY, radius, startAngle, endAngle){
				ctx.beginPath();
				ctx.arc(centerX, centerY, radius, startAngle, endAngle);
				ctx.stroke();
			}
			function drawPieSlice(ctx,centerX, centerY, radius, startAngle, endAngle, color ){
				ctx.fillStyle = color;
				ctx.beginPath();
				ctx.moveTo(centerX,centerY);
				ctx.arc(centerX, centerY, radius, startAngle, endAngle);
				ctx.closePath();
				ctx.fill();
			}
			//drawLine(ctx,100,100,200,200);
			//drawArc(ctx, 150,150,150, 0, Math.PI/3);
			//drawPieSlice(ctx, 150,150,150, 0, 3.14/3, '#ff0000');
			
			
			var myVinyls;
			myVinyls={0:parseInt(data[0]),1:parseInt(data[1]),2:parseInt(data[2])};
				
			
var Piechart = function(options){
    this.options = options;
    this.canvas = options.canvas;
    this.ctx = this.canvas.getContext("2d");
    this.colors = options.colors;
 
    this.draw = function(){
        var total_value = 0;
        var color_index = 0;
        for (var categ in this.options.data){
            var val = this.options.data[categ];
            total_value += val;
        }
        var start_angle = 0;
        for (categ in this.options.data){
            val = this.options.data[categ];
            var slice_angle = 2 * Math.PI * val / total_value;
 
            drawPieSlice(
                this.ctx,
                this.canvas.width/2,
                this.canvas.height/(4/3),
                Math.min(this.canvas.width/4,this.canvas.height/(4/3)),
                start_angle,
                start_angle+slice_angle,
                this.colors[color_index%this.colors.length]
            );
 
            start_angle += slice_angle;
            color_index++;
        }
 
        //drawing a white circle over the chart
        //to create the doughnut chart
        if (this.options.doughnutHoleSize){
			start_angle = 0;
		for (categ in this.options.data){
		val = this.options.data[categ];
		slice_angle = 2 * Math.PI * val / total_value;
		var pieRadius = Math.min(this.canvas.width/4,this.canvas.height/(4/3));
		var labelX = this.canvas.width/2 + (pieRadius / 2) * Math.cos(start_angle + slice_angle/2);
		var labelY = this.canvas.height/(4/3) + (pieRadius / 2) * Math.sin(start_angle + slice_angle/2);
 
		if (this.options.doughnutHoleSize){
			var offset = (pieRadius * this.options.doughnutHoleSize ) / 2;
			labelX = this.canvas.width/2 + (offset + pieRadius / 2) * Math.cos(start_angle + slice_angle/2);
			labelY = this.canvas.height/(4/3) + (offset + pieRadius / 2) * Math.sin(start_angle + slice_angle/2);               
		}
 
			var labelText = Math.round(100 * val / total_value);
			this.ctx.fillStyle = "white";
			this.ctx.font = "bold 20px Arial";
			this.ctx.fillText(labelText+"%", labelX,labelY);
			start_angle += slice_angle;
		}
            drawPieSlice(
                this.ctx,
                this.canvas.width/2,
                this.canvas.height/(4/3),
                this.options.doughnutHoleSize * Math.min(this.canvas.width/4,this.canvas.height/(4/3)),
                0,
                2 * Math.PI,
                "#FFFFFF"
            );
        }
 
    }
}

var myDougnutChart = new Piechart(
    {
        canvas:myCanvas,
        data:myVinyls,
        colors:["#fde23e","#f16e23", "#57d9ff","#937e88","#ff0000"],
        doughnutHoleSize:0.5
    }
);
myDougnutChart.draw();

		

           var gradient = ctx.createLinearGradient(0,0,0,300);
 

 
 
           ctx.fillStyle = gradient;
 
           ctx.fillRect(0,0,myCanvas.width,myCanvas.height);
 
           var realheight = myCanvas.height-800;
           var realwidth = myCanvas.width-100;

           var grid_cols = data.length + 1;
           var grid_rows = 3;
           var cell_height = realheight / grid_rows;//
           var cell_width = realwidth / grid_cols;
           ctx.lineWidth = 1;
           ctx.strokeStyle = "#a0a0a0";
 

           ctx.beginPath();

          

             ctx.moveTo(0,realheight);
             ctx.lineTo(realwidth+500,realheight);
                

           ctx.moveTo(0,20);
            ctx.lineTo(0,realheight);
           ctx.lineWidth = 1;
           ctx.strokeStyle = "black";
           ctx.stroke();
              
 
           var max_v =0;
          
           for(var i = 0; i< data.length ; i++){
             if ( parseInt(data[i]) > max_v) 
			 { 	
					
					max_v =data[i];
			}
           }
		   
           max_v = max_v * 1.1;
           var points = [];
           for( var i=0; i <  data.length ; i++){
             var v= data[i];
             var px = cell_width *　(i +1);
             var py = realheight - realheight*(v/max_v);

             points.push({"x":px,"y":py});
           }
 

           for(var i in points){
             var p = points[i];
             ctx.beginPath();
             ctx.fillStyle="pink";
             ctx.fillRect(p.x,p.y,15,realheight-p.y);
             
             ctx.fill();
           }

           for(var i in points)
           {  var p = points[i];
             ctx.beginPath();
             ctx.fillStyle="black";
             ctx.fillText(data[i], p.x +1, p.y-5);
              ctx.fillText(xinforma[i],p.x-10,realheight+20);
              ctx.fillText('Item ID',realwidth-60,realheight+25);
              ctx.fillText('Order Number',10,20);
            }
         },false);
       })();
       
</script>
</html >