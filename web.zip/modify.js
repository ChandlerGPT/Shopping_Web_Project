function check() {
	var password = document.getElementById("password").value;
	var flag=true;
	var al="";
	if(password==""){
		al=al+"Please input Password";
		flag=false;
	}
	if(flag==false){
		alert(al);
	}
	else{
		var myRequest = new XMLHttpRequest();
		myRequest.open("GET", "modify.php?userid="+userid, true);
		myRequest.send();
		myRequest.onload = function(){
			document.getElementById("msg").innerHTML =
			"<span style='color:red'>"+this.responseText+"</span>";
			if(this.responseText=="Succcess!"){
				document.getElementById('registed').submit();
			}
		}
	}
}