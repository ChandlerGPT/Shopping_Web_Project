function check() {
	var userid = document.getElementById("userid").value;
	var password = document.getElementById("password").value;
	var flag=true;
	var al="";
	if(userid==""){
		al=al+"Please input UserId\n";
		flag=false;
	}
	if(password==""){
		al=al+"Please input Password";
		flag=false;
	}
	if(flag==false){
		alert(al);
	}
	else{
		var myRequest = new XMLHttpRequest();
		myRequest.open("GET", "sign-up.php?userid="+userid, true);
		myRequest.send();
		myRequest.onload = function(){
			document.getElementById("msg").innerHTML =
			"<span style='color:red'>"+this.responseText+"</span>";
			if(this.responseText=="Succcess!"){
				document.getElementById('registed').submit();
			}
		}
	}
}