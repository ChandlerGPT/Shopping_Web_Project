<?php
	session_start();
?>
<!DOCTYPE html> 
<html> 
	<head>  
		<title>Home</title>  
		<link rel="stylesheet" type="text/css" href="shop.css"/> 
	</head> 
	
	
	<body> 
			<?php	
				
				if (!isset($_POST['type'])&&!isset($_POST['userid'])){
					if(!isset($_SESSION["type"])&&!isset($_SESSION["userid"])){
						$userid=$_COOKIE["userid"];
						$type=$_COOKIE["type"];
						$_SESSION["type"] = $type;
						$_SESSION["userid"] = $userid;
					}
					else{
						$type=$_SESSION["type"];
						$userid=$_SESSION["userid"];
					}
				}
				else{
					$type = $_POST['type'];
					$_SESSION["type"] = $type;
					$userid = $_POST['userid'];
					$_SESSION["userid"] = $userid;
					setcookie("userid","$userid", time() + (60 * 60 * 24));
					setcookie("type","$type", time() + (60 * 60 * 24));
				}
				if($type=="admin"){
					header("location:adminpage.php");
				}
				setcookie("userid", $userid, time() + (60 * 60 * 24));
				$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
				$connect = mysqli_connect($server, $user, $pw, $db);
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['profile']);
				}
				if($imgdata==""){
					$userQuery = "SELECT * FROM users where userid='unknown' and type='customer'";
					$result=mysqli_query($connect, $userQuery);
					while($rr=mysqli_fetch_assoc($result)){
						$imgdata=base64_encode($rr['profile']);
					}
				}
				$userQuery = "SELECT * FROM users where userid='$userid' and type='customer'";
				$result=mysqli_query($connect, $userQuery);
				while($rr=mysqli_fetch_assoc($result)){
					$nickname=$rr['nickname'];
				}
				print("
				<ul>
					<li><a class=\"active\" href=\"userhome.php\">All</a></li>
					<li><a href=\"Male.php\">Male</a></li>
					<li><a href=\"Female.php\">Female</a></li>
					<li><a href=\"cart.php\">Cart</a></li>
					<li style=\"float:right\"><a href=\"userpage.php\"><img id=\"pp\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \"></a></li>
					<li style=\"float:right\"><a>Welcome $nickname!</a></li>
					
				</ul>
				
				");
				print("<br><br><p align=\"center\"><img src=\"shop.png\" width=\"400\"></p>");
				print("<table><tr>");
				$userQuery = "SELECT * FROM item";
				$result=mysqli_query($connect, $userQuery);
				$cnt=0;
				while($rr=mysqli_fetch_assoc($result)){
					$imgdata=base64_encode($rr['picture']);
					print("<td><img class=\"item\" src=\"data:image/jpg;charset=utf8;base64,$imgdata \">
						<p>Price:$".strval($rr['price'])."</p>
						<p><form action = \"addcart.php\" method = \"post\" id = \"addcart\"><input type=\"hidden\" name=\"itemid\" value=\"".strval($rr['itemid'])."\"/><input  class=\"button2\" type=\"submit\" value=\"Add to cart\"/></form></p>
						</td>");
					$cnt=$cnt+1;
					if($cnt==4){
						$cnt=0;
						print("</tr><tr>");
					}
				}
				print("</tr></table>");
				
				mysqli_close($connect);
			?>

	</body>
</html> 
 