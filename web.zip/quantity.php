<?php
	session_start();
	$server = "localhost"; $user = "wbip"; $pw = "wbip123"; $db = "test";
	$connect = mysqli_connect($server, $user, $pw, $db);
	if(!$connect) {
		die("Connection failed: " . mysqli_connect_error());
	}
	$userid = $_SESSION["userid"];
	$itemid = $_POST["itemid"];
	$quantity = $_POST["quantity"];
	$userQuery="SELECT * FROM item WHERE itemid='$itemid'";
	$result=mysqli_query($connect, $userQuery);
	$rr=mysqli_fetch_assoc($result);
	$price=$rr['price'];
	$userQuery="DELETE FROM cart WHERE itemid='$itemid'";
	mysqli_query($connect, $userQuery);
	if($quantity<=0){
		header("location:cart.php");
	}
	else{
		$userQuery = "INSERT INTO cart(userid,itemid,quantity,price) VALUE ('".$userid."','".$itemid."','".$quantity."','".$price."')";
		mysqli_query($connect, $userQuery);
	}
	//$_SESSION["userid"] = $userid;
	header("location:cart.php");
	
	mysqli_close($connect);
?>